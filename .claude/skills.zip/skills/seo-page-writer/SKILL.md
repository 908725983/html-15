---
name: seo-page-writer
description: Write production-grade SEO landing pages, comparison pages, alternatives pages, how-to guides, and concept-explainer pages. Use whenever the user asks to write, draft, create, or generate any SEO-targeted webpage, blog post for organic search, marketing page targeting search keywords, vs/comparison page, "best X alternatives" page, "how to" guide page, or "what is X" page. Also trigger when the user mentions writing content for ranking on Google, targeting keywords, or building a topic cluster page. Produces a complete HTML file with proper E-E-A-T signals, JSON-LD schema, keyword distribution, Featured Snippet optimization, and Core Web Vitals compliance.
---

# SEO Page Writer

Write production-grade SEO pages that follow a strict execution-layer SOP. Each page must hit E-E-A-T signals, semantic entity coverage, Featured Snippet optimization, multi-schema structured data, and Core Web Vitals compliance — not just keyword stuffing.

## When this skill applies

Trigger this skill for any of:
- Writing a new SEO page from scratch (vs page, alternatives page, how-to, what-is, etc.)
- Refreshing or rewriting an existing SEO page
- The user asks for "an SEO-optimized page about X" or names a target keyword
- The user mentions a comparison ("A vs B"), an alternatives list, or a how-to targeting search

If the user just wants a casual blog post with no SEO intent, skip this skill.

## The workflow is non-negotiable

This skill enforces a 4-phase workflow. Do NOT skip phases or shortcut to writing HTML. Each phase has hard requirements that the next phase depends on.

```
Phase 1: Intake        → gather inputs, classify page type
Phase 2: Research      → SERP check, entity list, gap analysis, info-gain plan
Phase 3: Outline       → write outline, get user confirmation BEFORE writing HTML
Phase 4: Build         → produce HTML, run self-audit, deliver
```

---

## Phase 1 — Intake (gather inputs)

Before doing anything else, collect these inputs from the user. If any are missing, ask in one batch (not one-by-one):

**Required:**
1. **Primary keyword** — the one head term the page targets
2. **Long-tail keywords** — 2-3 related phrases to distribute through the page
3. **Page type** — one of: `comparison` / `alternatives` / `how-to` / `what-is` / `other`
4. **Brand & product info** — brand name, product name, one-sentence value prop, primary CTA URL
5. **Author info** — name, job title, one-line credentials (E-E-A-T requires this)
6. **Competitors covered** (for comparison/alternatives pages) — names + 1-2 lines on each
7. **Theme** — `light` or `dark`. **No default.** Ask the user explicitly before doing anything else. This is the FIRST question in the intake batch — put it at the top of the questions list so the user can't miss it. The scaffold supports both via `data-theme` on `<html>`. If the user has provided an existing sample page, infer from it but still confirm. If the user says "you decide" or "doesn't matter", push back once — the answer determines every CSS token on the page, and getting it wrong means rebuilding. If they still won't choose, default to `dark` and flag this in the delivery message.

**Strongly recommended (ask but don't block):**
8. **Internal data points** — any benchmarks, stats, customer numbers the user can share. This is what makes the page win on Information Gain.
9. **Existing site URLs** for internal linking (5+ relevant pages)
10. **Brand color tokens / existing design** — if writing for an established site, match it. If brand tokens conflict with the chosen theme (e.g. user picked `dark` but brand colors are pastel), surface the conflict in Phase 3 outline review, not after the page is built.

If the user has already provided a sample page (like a previous SEO page), read it with `view` to extract: brand voice, color palette, layout conventions, footer structure. Then reuse those.

> **Do not proceed to Phase 2 until inputs are complete.** Ask once, get answers, move on.

---

## Phase 2 — Research (do this before writing anything)

This phase produces a research brief that drives the outline. **Do not skip.**

### 2.1 SERP intent check

Use `web_search` on the primary keyword. Look at the top 10 results and answer:
- What format dominates? (Listicle / comparison table / long-form guide / video / forum thread)
- What intent? (Informational / Commercial / Transactional)
- What SERP features are present? (Featured Snippet / People Also Ask / Image Pack / Video)

**Iron rule**: the page format must match what's already ranking. If the top 10 are all comparison tables, do not write a narrative essay — it will not rank.

### 2.2 Competitor gap analysis

Open the top 3-5 competing pages with `web_fetch`. For each, note:
- Their H2 outline (what subtopics they cover)
- Their word count (rough)
- Whether they have original data, charts, FAQ
- What they DON'T cover (this is your opening)

The new page must cover **at least 30% more subtopics** than the strongest competitor, plus fill at least one gap.

### 2.3 Featured Snippet & PAA capture

If the SERP shows a Featured Snippet, note its format (paragraph / list / table) and length (~40-60 words). The page will design an H2 + answer block specifically to take that position.

If People Also Ask is present, capture the exact PAA questions verbatim — they go into FAQ. Use `web_search` for "{primary keyword}" and inspect the PAA box.

### 2.4 Semantic entity list

List 20-40 entities Google expects to see for this topic. Mix:
- Technical concepts (e.g., for "AI data analyst": SQL, Python, warehouse, semantic layer, text-to-SQL)
- Platforms (Snowflake, Databricks, BigQuery)
- Tools (Tableau, Power BI)
- Roles (data analyst, analytics engineer)
- Use cases (dashboard, ad-hoc query, forecasting)

The page should naturally cover **80%+ of this list**. Do not stuff — weave them into context.

### 2.5 Information Gain plan

Decide what makes this page **uniquely worth reading**. Pick at least one:
- [ ] Original benchmark or data (with method + sample size)
- [ ] Customer interview or case (with name + role + numbers)
- [ ] Proprietary framework or methodology (with a name, ideally)
- [ ] Original chart or diagram

Without info gain, the page is a dupe and will not rank.

### 2.6 Output: research brief

After Phase 2, present a compact brief to the user:
```
SERP intent: [Informational / Commercial / Transactional]
Dominant format: [comparison table / long-form guide / etc.]
Featured Snippet present: [yes/no, format if yes]
PAA questions (verbatim): [list]
Top 3 competitors covered: [list]
Subtopics they all cover: [list]
Gaps to exploit: [list]
Entities to cover: [list, ~20-40]
Info gain plan: [what unique thing this page brings]
```

Then move to Phase 3.

---

## Phase 3 — Outline (get user sign-off BEFORE writing HTML)

Read the right reference based on page type:

| Page type | Read this reference |
|---|---|
| `comparison` (A vs B / A vs B vs C) | `references/comparison-template.md` |
| `alternatives` (Best X Alternatives) | `references/alternatives-template.md` |
| `how-to` (How to do X) | `references/how-to-template.md` |
| `what-is` (What is X / X explained) | `references/what-is-template.md` |

Each reference gives the H1 formula, H2 structure, schema choices, and module specifics for that type.

Produce an outline:
- H1 (final wording)
- Meta title (40-60 chars) + meta description (150-160 chars)
- All H2s in order
- For each H2: a 1-line summary of what it'll cover
- FAQ list (4-6 questions, drawn from PAA + standard reverse/integration/competitor/ROI/proof slots)
- Featured Snippet target H2 + planned answer (40-60 words)
- Schema list (which JSON-LD blocks the page will include)
- Original visualization plan (what chart/diagram to include)

Show this outline to the user. **Wait for confirmation or edits.** Do not write the HTML until the user signs off.

---

## Phase 4 — Build (produce the HTML)

### 4.1 Read the build references

Before writing HTML, read these in order:
1. `references/page-structure.md` — the canonical 17-block page structure with code patterns for each block
2. `references/schema-library.md` — copy-paste JSON-LD blocks for every required schema type
3. `references/keyword-placement.md` — exact placement table for primary + long-tail keywords
4. `references/style-rules.md` — voice, sentence patterns, banned phrases

### 4.2 Use the HTML scaffold

Open `assets/page-scaffold.html` as the starting template. It contains:
- All 17 page blocks pre-stubbed with comments
- A unified theme token system (`:root` for dark, `[data-theme="light"]` for light) — every color is a CSS variable, so the SAME scaffold renders correctly in either theme
- An automatic `@media (prefers-color-scheme)` fallback used ONLY if `data-theme` is unset
- Schema placeholders ready to fill
- Mobile breakpoints

**Set the theme first.** The scaffold's `<html>` tag has `data-theme="{{THEME}}"`. Replace `{{THEME}}` with `light` or `dark` based on the Phase 1 answer. Do this before any other replacement — every CSS variable depends on it.

If the user provided brand color tokens that differ from the scaffold's defaults, override them inside the matching theme block (`:root` for dark, `[data-theme="light"]` for light). Do not delete the other theme block — keeping it intact makes the page resilient to a future theme switch.

Fill in section by section. Do not delete or reorder blocks. Do not skip the E-E-A-T author block, the Methodology block, or the Featured Snippet block — these are required for the page to compete.

### 4.3 Write the prose

Apply `references/style-rules.md` to every paragraph. Key rules (full list in the reference):
- Numbers > adjectives ("50-65% accuracy" not "lower accuracy")
- Source > assertion (every data point has a source line)
- Honesty > marketing (mention when competitors win)
- Short paragraphs (≤ 4 lines)
- Second person ("your team")
- Each H2 ends with a "so who should pick this" call

### 4.4 Self-audit (mandatory before delivery)

Read `references/audit-checklist.md` and run through every item. The page is not done until every box is checked. If any item fails, fix and re-audit. Common failures:
- H1 missing primary keyword
- Title > 60 chars
- No author block
- No data source on a stat
- Primary keyword > 8 occurrences (stuffing)
- No original visualization
- Methodology block missing
- Schema not validating

### 4.5 Auto-audit the 11 hard metrics

After the manual checklist passes, run the automated metric audit. This catches the eleven "hard" technical metrics that are tedious to count by eye and that the page is not allowed to ship without:

```bash
python3 assets/audit-page.py /mnt/user-data/outputs/{slug}.html
```

If the user provided their site domain in Phase 1, pass it so that absolute links to that domain are counted as internal:

```bash
python3 assets/audit-page.py /mnt/user-data/outputs/{slug}.html --site-domain example.com
```

The script prints a table of 11 PASS/FAIL rows. **Every metric must PASS before delivery.** The 11 metrics are:

| # | Metric | Threshold |
|---|---|---|
| 1 | Title length | 40-60 chars |
| 2 | Meta description length | 150-160 chars |
| 3 | `<h1>` count | exactly 1 |
| 4 | `<h2>` count | ≥ 4 |
| 5 | `<h3>` count | ≥ 1 |
| 6 | Canonical | absolute `https://...` |
| 7 | Open Graph + Twitter Card | og:title, og:description, og:image, og:url, twitter:card all present |
| 8 | Image alt | every `<img>` has a non-empty `alt` |
| 9 | Internal links | ≥ 5 |
| 10 | External links | ≥ 1 |
| 11 | JSON-LD blocks | ≥ 5 |

If any row says FAIL, fix the page (do not edit the script) and re-run until exit code is 0. The most common first-pass FAILs and their fixes:

- **Title or description length off** — tighten or pad until in range. Do not pad with filler words; trim brand suffix or rewrite.
- **Only 4 JSON-LD blocks** — the scaffold stubs 4 (Organization, BreadcrumbList, Article, FAQPage). Add at least one page-type schema (HowTo for how-to, ItemList for alternatives, DefinedTerm for what-is, or SoftwareApplication for comparison) to hit ≥ 5.
- **Internal links < 5** — weave 2-3 more contextual internal links into body H2 prose, or extend the Related Guides grid. Do not pad navigation with dummy links.
- **No external links** — add a citation to an authoritative source (government data, peer-reviewed paper, official docs) in the Methodology or a stat. External outbound links to authoritative sources are an E-E-A-T positive, not a leak.
- **Image missing alt** — every chart, diagram, headshot, and OG image needs descriptive alt text.

### 4.6 Validate the schema

Before delivery, mentally walk through each JSON-LD block to verify:
- All required fields present
- Content matches the visible page text exactly
- Dates in ISO format (`YYYY-MM-DD`)
- URLs are absolute, not relative

Tell the user to verify with Google Rich Results Test (`search.google.com/test/rich-results`) after deploy.

### 4.7 Deliver

Save the file as a single self-contained `.html` (CSS inline, no external dependencies beyond Google Fonts) to `/mnt/user-data/outputs/{kebab-case-slug}.html`. Then `present_files` it.

In the delivery message, include:
- One-line summary of what was produced
- The theme used (`light` or `dark`) — confirms the Phase 1 choice
- The slug used (so the user knows the recommended URL)
- The 11-metric audit result (e.g. "11/11 pass")
- A short "before deploy" checklist (verify schema, test mobile, run PageSpeed Insights)

---

## Hard rules (do NOT violate)

1. **Never write HTML in Phase 1 or 2.** Outline first, get sign-off, then build.
2. **Never skip the author block** — E-E-A-T is the #1 ranking factor for content sites in 2026.
3. **Never invent data.** If the user didn't provide a stat, either omit it or mark it `[NEEDS DATA — user to fill]` and flag at delivery.
4. **Never claim a competitor is bad without a specific reason and source.** Honest, evidence-based critique only.
5. **Never produce a page without at least 5 JSON-LD schema blocks** (Organization + BreadcrumbList + Article + FAQPage + page-type schema minimum).
6. **Never skip the audit checklist OR the auto-audit.** Self-audit is the human-judgment line; `audit-page.py` is the machine line. Both must pass before delivery.
7. **Never deliver if `audit-page.py` exits non-zero.** The 11 metrics are non-negotiable. If a metric cannot be made to pass (e.g. user explicitly refuses to add an external link), surface it at delivery as a known violation — do not hide it.
8. **Never pick the theme for the user.** `light` or `dark` is a required Phase 1 input. No default. If they refuse to choose after one push-back, fall back to `dark` and call out the assumption in the delivery message.

---

## When inputs are sparse

If the user gives a one-line request like "write me an SEO page about X", do NOT just guess. Run Phase 1 — ask the questions. Sparse inputs produce generic pages, and generic pages do not rank.

The only exception: if the user explicitly says "just go, use placeholders for what you don't know", then build with `[NEEDS INPUT: ...]` markers throughout, and clearly list everything they need to fill in at delivery.

---

## Reference index

- `references/comparison-template.md` — vs / A vs B vs C pages
- `references/alternatives-template.md` — Best X Alternatives pages
- `references/how-to-template.md` — How-to / tutorial pages
- `references/what-is-template.md` — Concept explainer / definition pages
- `references/page-structure.md` — 17-block canonical structure with code patterns
- `references/schema-library.md` — copy-paste JSON-LD for every schema type
- `references/keyword-placement.md` — exact placement table & density rules
- `references/style-rules.md` — voice, sentence patterns, banned phrases
- `references/audit-checklist.md` — pre-delivery self-audit (mandatory)
- `assets/page-scaffold.html` — starter HTML with all 17 blocks pre-stubbed
- `assets/audit-page.py` — Phase 4.5 auto-audit script for the 11 hard metrics (run before delivery)
