# SEO Page Writer Skill

> A Claude Code skill that produces production-grade SEO pages following a strict execution-layer SOP — E-E-A-T signals, multi-schema structured data, Featured Snippet capture, semantic keyword distribution, and Core Web Vitals compliance.

Stop writing one-shot SEO prompts that produce generic pages. This skill enforces a 4-phase workflow (Intake → Research → Outline → Build) so even with sparse input, the output meets 2026 Google ranking standards.

---

## What this skill does

Given a target keyword and minimal client info, Claude Code will:

1. **Ask** for the inputs it needs (keyword, audience, brand, author, competitors)
2. **Research** the SERP (top-10 analysis, PAA capture, competitor gap, entity coverage)
3. **Outline** the page and wait for your sign-off before writing HTML
4. **Build** a complete self-contained HTML file with proper schema, E-E-A-T signals, and a self-audit pass

Supports four page types out of the box:

- **Comparison pages** — `A vs B vs C`
- **Alternatives pages** — `Best X Alternatives for Y`
- **How-to pages** — `How to {do X} with {Y}`
- **What-is pages** — `What is X? {Benefit hook}`

---

## Why use this skill instead of one-shot prompting

A casual "write me an SEO page about X" prompt produces:
- Generic H1s that don't match search intent
- No E-E-A-T author block (a #1 ranking factor in 2026)
- One basic FAQPage schema if any
- Marketing adjectives instead of quantified claims
- No Featured Snippet capture block
- No methodology/transparency signals

This skill enforces:
- ✅ User picks light or dark theme up front (no default — both rendered from one scaffold via `data-theme` tokens)
- ✅ Real author block with credentials, dates, schema-linked
- ✅ At least 5 stacked JSON-LD schemas (Organization + BreadcrumbList + Article + FAQPage + page-type schema)
- ✅ Featured Snippet capture block (question H2 + 40-60 word answer)
- ✅ Original visualization placeholder (or actual chart if data provided)
- ✅ Methodology / conflict-of-interest block
- ✅ Mandatory self-audit checklist + automated 11-metric audit (`audit-page.py`) before delivery
- ✅ Honest competitor concessions (E-E-A-T trust signal)
- ✅ Verbatim PAA questions in FAQ (Featured Snippet alternates)
- ✅ Keyword density caps + semantic entity coverage
- ✅ Mobile breakpoints, Core Web Vitals-friendly markup

### The 11 hard metrics (auto-checked)

Every page must pass `assets/audit-page.py` (exit code 0) before delivery:

| # | Metric | Threshold |
|---|---|---|
| 1 | Title length | 40-60 chars |
| 2 | Meta description length | 150-160 chars |
| 3 | `<h1>` count | exactly 1 |
| 4 | `<h2>` count | ≥ 4 |
| 5 | `<h3>` count | ≥ 1 |
| 6 | Canonical link | absolute `https://...` |
| 7 | OG + Twitter Card | og:title/description/image/url + twitter:card all present |
| 8 | Image alt | every `<img>` has non-empty `alt` |
| 9 | Internal links | ≥ 5 |
| 10 | External links | ≥ 1 |
| 11 | JSON-LD blocks | ≥ 5 |

---

## Installation

### Option 1: Project-level install (recommended for client work)

Clone or download into your project's `.claude/skills/` directory:

```bash
cd your-project/
mkdir -p .claude/skills/
cd .claude/skills/
git clone https://github.com/{your-username}/seo-page-writer.git
```

Final structure:
```
your-project/
├── .claude/
│   └── skills/
│       └── seo-page-writer/      ← this repo
│           ├── SKILL.md
│           ├── references/
│           └── assets/
└── ... (your project files)
```

### Option 2: User-level install (available in all projects)

Install once at the user level:

- **macOS / Linux**:
  ```bash
  mkdir -p ~/.claude/skills/
  cd ~/.claude/skills/
  git clone https://github.com/{your-username}/seo-page-writer.git
  ```

- **Windows** (PowerShell):
  ```powershell
  mkdir -p $env:USERPROFILE\.claude\skills\
  cd $env:USERPROFILE\.claude\skills\
  git clone https://github.com/{your-username}/seo-page-writer.git
  ```

### Verify it's installed

Restart Claude Code, then in any session say:

```
帮我写一个 Tableau vs Power BI 的 SEO 对比页
```

If the skill loaded correctly, Claude **will not** start writing HTML immediately. Instead it will say something like:

> "I need a few inputs before starting. Please provide:
> 1. Theme — light or dark (no default, must choose)
> 2. Long-tail keywords (2-3)
> 3. Author info (name, role, credentials)
> ..."

If Claude jumps straight to writing HTML without asking questions, the skill isn't being detected — check the directory location.

---

## Usage Guide

> 装好 skill 之后,怎么跟 Claude Code 说话才能让它给你写出好页面。本节只讲"你怎么用",不讲背后机制。

### 最基本的启动咒语

复制这条,改两个空格里的内容,粘到 Claude Code:

```
用 seo-page-writer skill 帮我给客户【客户名】写一个 SEO 页面。

主关键词:【目标关键词】
我手上的素材就这些,缺的信息你按 skill 流程一步步问我,
缺数据的地方先用占位符,最后告诉我哪些要补。
```

发出去之后,Claude Code 会主动问你需要的信息。**你不会的就说不会,它会用占位符标记,不会瞎编**。

---

### 6 种使用场景 + 实战话术

#### 场景 1:超少素材(只知道关键词和客户名)

最常见的情况——客户刚发了个需求,你只知道关键词。

```
用 seo-page-writer skill,给客户 Acme 写一个 SEO 页面,
主关键词:best project management tools for agencies。
其他都不知道,你按 skill 流程问我,
不知道的我会说"猜一个合理的"或"留空标记"。
```

**会发生什么**:Claude 会问你 7 个核心问题(主题颜色 light/dark、长尾词、页面类型、品牌信息、作者署名、竞品、内部数据)。主题是必选的没默认值。能答多少答多少。最后产出会带 `[NEEDS DATA]` 标记,告诉你哪些要补。

---

#### 场景 2:客户官网链接是你最大的杠杆

这条特别好用——让 Claude 自己去客户网站读品牌信息,你少打一堆字。

```
用 seo-page-writer skill,给客户写 SEO 页面。

主关键词:AI customer support automation
客户官网:https://acmesupport.io
你先 fetch 这个网站,品牌名、产品定位、设计风格、footer 结构、
配色都从这里提取。

作者用我的名字:张三 / Senior SEO Specialist / 8 年 B2B SEO 经验。
其他按 skill 流程问。
```

**会发生什么**:Claude 自动抓客户官网,品牌信息它自己提取。你只需要补它读不到的(作者署名、内部数据等)。

---

#### 场景 3:客户邮件原文直接粘过去

最省时间的做法——客户怎么写需求,你怎么粘。

```
用 seo-page-writer skill 帮这个客户写 SEO 页面。

客户原话如下:
"我们想做一个页面排到 'best CRM for real estate' 前几名。
我们的产品叫 RealtyCRM,主打中小型房产中介,定价 $29/user/month。
主要竞品是 Follow Up Boss 和 LionDesk。希望强调我们的 AI 自动跟进功能。"

按 skill 流程,缺的问我。
```

**会发生什么**:Claude 自动从邮件里抓出主关键词、产品、定价、竞品、卖点,然后只问真正缺的部分(作者信息、长尾词、benchmark 等)。

> 💡 **诀窍**:客户给的任何素材——微信聊天记录、销售 PPT 文字、Notion 笔记、产品介绍 PDF——直接粘,别概括。你越概括 Claude 越没素材。

---

#### 场景 4:素材较全的对比页

如果客户给了完整的产品资料和竞品分析。

```
用 seo-page-writer skill 写对比页。

主关键词:Notion vs Coda vs Airtable
长尾词:project management for startups / no-code database / team workspace
我们是 Coda,客户给的素材在下面:

【粘贴客户给的产品介绍、benchmark、定价、客户案例等】

竞品就是 Notion 和 Airtable。
作者:李四 / Coda Solutions Engineer / 5 年产品经验。
按 skill 流程,有不清楚的再问我。
```

**会发生什么**:Claude 把你给的素材消化进去,只问关键缺口,直接进入大纲阶段。出活快。

---

#### 场景 5:同一个客户做第二、第三个页面

第一次做完后,**保留产出的 HTML 文件**作为参考。第二次:

```
用 seo-page-writer skill 给同一个客户 RealtyCRM 再写一个页面。
参考之前那篇 /output/realtycrm-vs-followupboss.html 的品牌设计、
作者署名、footer、配色、内链结构。

新页面:
- 类型:替代品页
- 主关键词:best Follow Up Boss alternatives
- 竞品名单:RealtyCRM(自家)、LionDesk、Wise Agent、kvCORE

直接进 Phase 2 调研,Phase 1 的客户基础信息从前一篇里继承。
```

**会发生什么**:Claude 跳过初始问答,直接复用前一篇的品牌信息,只针对新页面做调研。**省掉 5 分钟问答**。

---

#### 场景 6:客户什么都不肯给,但你必须出草稿

经常遇到——客户说"先做出来给我看",但啥素材都不给。

```
用 seo-page-writer skill 写 SEO 页面。

主关键词:enterprise data warehouse migration
客户什么都没给我,你能从公网搜出来的就用,
搜不到的字段全部用 [NEEDS CLIENT INPUT: ...] 标记,
最后给我一份"客户必须填写的清单",我去找客户要。
```

**会发生什么**:Claude 产出一个带空白字段的可交付草稿。你拿这个草稿去给客户看——客户一看到具体的空白字段,会立刻反应过来该提供什么(比 Claude 干问要素材有效得多)。

> 💡 这个咒语解决了"客户不知道自己有什么素材"的死结。

---

### 几个进阶用法

#### 给客户行业垂直定调

如果客户是特定行业,在 prompt 里加一句:

```
受众是【医疗 / 法律 / 金融 / 制造业】的【CTO / 采购 / 一线员工】,
语气要【更技术 / 更保守 / 更直接】,术语【可以专业 / 必须解释】。
```

例如:

```
受众是医院 IT 负责人,语气要保守专业,合规相关术语必须出现
(HIPAA、PHI、BAA),不要用 startup 风格的口号。
```

#### 强制 Claude 引用你给的数据

如果你有一份客户的 benchmark 表格、客户案例、问卷数据,粘给 Claude 之后追加一句:

```
H2 #2 必须引用上面的 benchmark 数据,
H2 #4 必须用上面的客户案例(姓名+公司+具体数字)。
其他可以总结但不能编造数字。
```

这样能确保你最有价值的素材进到页面最显眼的位置。

#### 让 Claude 出多个标题让你挑

```
H1 给我 5 个候选,标注每个的:
- 字符数
- 主关键词位置
- 主打的搜索意图(选型 / 教程 / 对比)
让我选一个再继续写正文。
```

或者:

```
Meta description 给我 3 版:
A 版偏理性数据
B 版偏情绪痛点
C 版偏好奇心钩子
我选一个再继续。
```

#### 让 Claude 模仿某个参考页面的结构

```
参考这个页面的结构:https://stripe.com/guides/payment-methods
我要做的是同样结构、同样深度,但主题换成【你的主题】。
按 skill 流程走,但 H2 outline 直接对照参考页。
```

---

### 三个让产出更好的小习惯

**1. 把客户官网链接放进 prompt** — 让 Claude `web_fetch` 一下客户官网,品牌色、字体、footer、内链结构、产品话术全自动提取。

**2. 客户给的任何素材都直接粘上去,别概括** — 哪怕乱、长、格式不对——直接粘。Claude 提取信息能力比你想象强。

**3. 每个新客户的第一个页面,自己审一遍** — 第一篇出来后,认真过一遍 skill 自带的 audit checklist。改完后这一版就成了客户的"基准模板"。

---

### Claude Code 会主动帮你做的事(你不用操心)

- **关键词找不到长尾**:它会 web_search 扩展几个让你挑
- **不知道竞品**:它会搜 SERP 前 10 名,自动提取真实竞品
- **不知道写哪些 FAQ**:它会从 Google People Also Ask 直接抓真实问题
- **不知道行业惯用术语**:Phase 2 的实体清单会自动覆盖
- **没有内部 benchmark**:占位 + 交付清单标红,提醒你去找客户要
- **不会写 schema**:全自动生成,你不用懂 JSON-LD

**你只需要做的**:问什么答什么,不会的说不会,最后看大纲点头。

---

### 最常见的 5 个踩坑预警

#### 1. 不要试图在一句话里塞所有信息

❌ 把主词、长尾、竞品、作者、定价、CTA、品牌色全塞一段话——Claude 会漏读。
✅ 让它按 skill 流程一步步问。

#### 2. 作者信息别用"Editorial Team"

❌ "作者:Editorial Team"
✅ "作者:张三 / Senior Data Analyst / 8 年企业数据分析经验,前 Snowflake 解决方案工程师"

E-E-A-T 是 2026 年 Google 排名命门,匿名作者直接降权。

#### 3. 数据没有就说没有,千万别让 Claude "估计"

❌ "你估计一下我们产品的客户数,大概几千吧" → Claude 真的会写 "5,000+ customers"
✅ "客户数我没数据,标 [NEEDS DATA]"

**编出来的数据上线后被发现,SEO 信任分一夜归零**。

#### 4. 第一次合作的客户,做完后整理 brand kit

第一篇做完后花 5 分钟整理:品牌色、字体、tone of voice、footer 链接结构、标准作者署名。存成 `brandkit-{客户名}.md`,下次直接 paste 进 prompt 开头。

#### 5. 大纲阶段一定要认真审

Claude 会在 Phase 3 给你大纲,**让你确认再写 HTML**。这是改方向最便宜的时机。

---

### 不同情况下选哪条咒语?对照表

| 你的情况 | 用哪条 |
|---|---|
| 只知道关键词和客户名 | 场景 1 |
| 客户有官网,但素材没整理 | 场景 2 |
| 客户发了一段文字描述需求 | 场景 3 |
| 客户给了完整产品资料和竞品 | 场景 4 |
| 给同一客户做第二、第三个页面 | 场景 5 |
| 客户什么都不给但要看草稿 | 场景 6 |

---

## Repository structure

```
seo-page-writer/
├── SKILL.md                          # Main skill entry: 4-phase workflow
├── references/
│   ├── page-structure.md             # 17-block canonical page structure
│   ├── schema-library.md             # Copy-paste JSON-LD templates
│   ├── keyword-placement.md          # Keyword distribution rules + density caps
│   ├── style-rules.md                # Voice, sentence patterns, banned phrases
│   ├── audit-checklist.md            # Pre-delivery self-audit (mandatory)
│   ├── comparison-template.md        # vs / A vs B vs C pages
│   ├── alternatives-template.md      # Best X Alternatives pages
│   ├── how-to-template.md            # How-to / tutorial pages
│   └── what-is-template.md           # Concept explainer / definition pages
└── assets/
    ├── page-scaffold.html            # Starter HTML with all 17 blocks pre-stubbed (light + dark themes via data-theme)
    └── audit-page.py                 # Phase 4.5 auto-audit for the 11 hard metrics
```

---

## Customization

### Pick a theme (every page)

Every page is asked, in Phase 1, whether it should ship in `light` or `dark`. There is no default — the user must choose. The scaffold uses one set of CSS variables driven by `[data-theme="light"]` or `[data-theme="dark"]` on `<html>`, so both themes render from a single file.

If you don't set `data-theme` at all (e.g. building a preview), the scaffold falls back to `prefers-color-scheme` — it tracks the user's OS setting.

### Match your brand styling

`assets/page-scaffold.html` ships with two themes (`:root` / `[data-theme="dark"]` and `[data-theme="light"]`). To match your (or your client's) brand:

1. Open `assets/page-scaffold.html`
2. Edit the CSS variables inside the **matching theme block** (e.g. change `--accent`, `--bg-page`, `--text-strong` under `[data-theme="light"]` if your brand is light-themed)
3. Leave the other theme block intact so the page is still resilient to a theme switch
4. Replace the footer link structure with your real site map

After this one-time edit, every page generated will use your styling.

### Add a new page type

To add support for a new page type (e.g., `case-study`):

1. Create `references/case-study-template.md` following the pattern of existing templates
2. Add the new type to the routing table in `SKILL.md`'s "Phase 3 — Outline" section
3. Update the H1 formula table in `SKILL.md`

---

## Contributing

Issues and PRs welcome. If you find a category of pages this skill doesn't handle well, open an issue with:
- The keyword you tried
- What output you got
- What output you expected

---

## License

MIT — see [LICENSE](LICENSE) for details.

---

## Credits

Built on the [Claude Code skills](https://docs.claude.com/en/docs/claude-code/skills) system. Inspired by SEO best practices for the post-Helpful-Content-Update era (E-E-A-T, Information Gain, Topical Authority).
