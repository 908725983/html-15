#!/usr/bin/env python3
"""
audit-page.py — Phase 4.5 auto-audit for the 11 hard SEO metrics.

Run after the HTML is produced and BEFORE present_files. The skill MUST
re-run this until every metric passes (or surface failures to the user
with a clear note that the page does not meet the bar).

Usage:
    python3 audit-page.py /path/to/page.html

Optional flag:
    --site-domain example.com    Treat links to example.com (and subdomains)
                                 as internal even when they use absolute URLs.

The 11 hard metrics (mirror of the spec image):
    1.  Title length 40-60 chars
    2.  Meta description length 150-160 chars
    3.  Exactly one <h1>
    4.  At least 4 <h2>
    5.  At least 1 <h3>
    6.  Canonical link present AND absolute (https://)
    7.  Open Graph (og:title, og:description, og:image, og:url)
       + Twitter Card (twitter:card) all present
    8.  Every <img> has a non-empty alt attribute
    9.  At least 5 internal links
    10. At least 1 external link
    11. At least 5 JSON-LD <script type="application/ld+json"> blocks

Exit code 0 if all pass, 1 otherwise. The output is a plain table — the
skill caller reads it and fixes any FAIL row before re-running.

No third-party dependencies. Uses only the stdlib html.parser + re.
"""

from __future__ import annotations

import argparse
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse


# ---------- Parser ----------

class PageInspector(HTMLParser):
    """Collects every signal we need for the 11 metrics in one pass."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title_text: str = ""
        self._in_title = False

        self.meta: dict[str, str] = {}        # name=description, robots, etc.
        self.og: dict[str, str] = {}          # property=og:*
        self.twitter: dict[str, str] = {}     # name=twitter:*
        self.canonical: str = ""

        self.h1_count = 0
        self.h2_count = 0
        self.h3_count = 0

        self.images: list[dict] = []          # each: {"alt": str|None, "src": str}

        self.links: list[str] = []            # every href on the page

        self.jsonld_blocks = 0
        self._in_jsonld = False

    # ---- text capture ----
    def handle_starttag(self, tag: str, attrs_list) -> None:
        attrs = dict(attrs_list)
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            name = (attrs.get("name") or "").lower()
            prop = (attrs.get("property") or "").lower()
            content = attrs.get("content", "")
            if prop.startswith("og:"):
                self.og[prop] = content
            elif name.startswith("twitter:"):
                self.twitter[name] = content
            elif name:
                self.meta[name] = content
        elif tag == "link":
            rel = (attrs.get("rel") or "").lower()
            if "canonical" in rel:
                self.canonical = attrs.get("href", "")
        elif tag == "h1":
            self.h1_count += 1
        elif tag == "h2":
            self.h2_count += 1
        elif tag == "h3":
            self.h3_count += 1
        elif tag == "img":
            self.images.append({
                "alt": attrs.get("alt"),
                "src": attrs.get("src", ""),
            })
        elif tag == "a":
            href = attrs.get("href", "").strip()
            if href:
                self.links.append(href)
        elif tag == "script":
            if (attrs.get("type") or "").lower() == "application/ld+json":
                self.jsonld_blocks += 1
                self._in_jsonld = True

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
        elif tag == "script" and self._in_jsonld:
            self._in_jsonld = False

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_text += data


# ---------- Link classification ----------

# A link is INTERNAL if:
#   - it starts with "/" (not "//"), or
#   - it is purely a fragment "#..." or "?..." (same-page), or
#   - its host matches the optional --site-domain (or a subdomain of it).
# Mailto/tel/javascript are ignored (counted as neither).
# Absolute http(s) links to other domains count as EXTERNAL.

def classify_link(href: str, site_domain: str | None) -> str:
    """Return 'internal', 'external', or 'ignore'."""
    if not href:
        return "ignore"
    href = href.strip()
    lower = href.lower()
    if lower.startswith(("mailto:", "tel:", "javascript:")):
        return "ignore"
    # protocol-relative "//host/..." → treat as absolute external
    if href.startswith("//"):
        return "external"
    # root-relative or in-page anchor
    if href.startswith(("/", "#", "?")):
        return "internal"
    parsed = urlparse(href)
    if not parsed.scheme:
        # plain relative path like "blog/post" → internal
        return "internal"
    if parsed.scheme in ("http", "https"):
        host = (parsed.hostname or "").lower()
        if site_domain:
            sd = site_domain.lower().lstrip(".")
            if host == sd or host.endswith("." + sd):
                return "internal"
        return "external"
    return "ignore"


# ---------- Check helpers ----------

def fmt_row(idx: int, name: str, ok: bool, detail: str) -> str:
    badge = "PASS" if ok else "FAIL"
    return f"  {idx:>2}. [{badge}] {name:<32}  {detail}"


def run_audit(html: str, site_domain: str | None) -> tuple[int, list[str]]:
    """Return (fail_count, rendered_rows)."""
    p = PageInspector()
    p.feed(html)

    rows: list[str] = []
    fails = 0

    def check(idx: int, name: str, ok: bool, detail: str) -> None:
        nonlocal fails
        if not ok:
            fails += 1
        rows.append(fmt_row(idx, name, ok, detail))

    # 1. Title 40-60
    title = p.title_text.strip()
    tl = len(title)
    check(1, "Title 40-60 chars", 40 <= tl <= 60,
          f"got {tl} chars — '{title[:50]}{'...' if tl > 50 else ''}'")

    # 2. Description 150-160
    desc = (p.meta.get("description") or "").strip()
    dl = len(desc)
    check(2, "Description 150-160 chars", 150 <= dl <= 160,
          f"got {dl} chars")

    # 3. Single H1
    check(3, "Exactly one <h1>", p.h1_count == 1,
          f"got {p.h1_count}")

    # 4. H2 >= 4
    check(4, "<h2> count >= 4", p.h2_count >= 4,
          f"got {p.h2_count}")

    # 5. H3 >= 1
    check(5, "<h3> present", p.h3_count >= 1,
          f"got {p.h3_count}")

    # 6. Canonical absolute
    canon = p.canonical.strip()
    canon_ok = canon.lower().startswith("https://")
    check(6, "Canonical absolute (https://)", canon_ok,
          f"href='{canon}'" if canon else "missing <link rel=canonical>")

    # 7. OG + Twitter Card
    required_og = ["og:title", "og:description", "og:image", "og:url"]
    missing_og = [k for k in required_og if not p.og.get(k, "").strip()]
    twitter_card = p.twitter.get("twitter:card", "").strip()
    og_twitter_ok = (not missing_og) and bool(twitter_card)
    if og_twitter_ok:
        detail = "all OG + twitter:card present"
    else:
        parts = []
        if missing_og:
            parts.append(f"missing OG: {', '.join(missing_og)}")
        if not twitter_card:
            parts.append("missing twitter:card")
        detail = "; ".join(parts)
    check(7, "OG + Twitter Card complete", og_twitter_ok, detail)

    # 8. All img have alt
    missing_alt = [img["src"] or "(no src)" for img in p.images if not (img["alt"] or "").strip()]
    img_ok = len(missing_alt) == 0
    if not p.images:
        # No images at all is technically fine for the alt check, but flag it
        # as a soft note (still PASS because nothing violates the rule).
        check(8, "All <img> have non-empty alt", True, "no <img> tags found")
    else:
        check(8, "All <img> have non-empty alt", img_ok,
              f"{len(p.images)} imgs, {len(missing_alt)} missing alt"
              + (f" — first: {missing_alt[0][:60]}" if missing_alt else ""))

    # 9. Internal links >= 5
    # 10. External links >= 1
    internal = external = 0
    for href in p.links:
        cls = classify_link(href, site_domain)
        if cls == "internal":
            internal += 1
        elif cls == "external":
            external += 1
    check(9, "Internal links >= 5", internal >= 5, f"got {internal}")
    check(10, "External link >= 1", external >= 1, f"got {external}")

    # 11. JSON-LD blocks >= 5
    check(11, "JSON-LD blocks >= 5", p.jsonld_blocks >= 5,
          f"got {p.jsonld_blocks}")

    return fails, rows


# ---------- CLI ----------

def main() -> int:
    ap = argparse.ArgumentParser(description="11-metric SEO auto-audit")
    ap.add_argument("html_path", help="Path to the rendered HTML page")
    ap.add_argument("--site-domain", default=None,
                    help="Optional brand domain (e.g. example.com). "
                         "Absolute links to this host count as internal.")
    args = ap.parse_args()

    path = Path(args.html_path)
    if not path.exists():
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2
    html = path.read_text(encoding="utf-8", errors="replace")

    fails, rows = run_audit(html, args.site_domain)

    print(f"\n11-Metric SEO Audit — {path.name}")
    print("=" * 72)
    for r in rows:
        print(r)
    print("=" * 72)
    if fails == 0:
        print("RESULT: all 11 metrics pass.\n")
        return 0
    print(f"RESULT: {fails} FAIL(s). Fix the rows marked [FAIL] and re-run.\n")
    return 1


if __name__ == "__main__":
    sys.exit(main())
