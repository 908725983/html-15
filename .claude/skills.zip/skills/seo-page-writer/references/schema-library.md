# Schema Library — Copy-Paste JSON-LD

> Every page has at least 5 schema blocks: `Organization` + `BreadcrumbList` + `Article` + `FAQPage` + at least one page-type schema (`HowTo` / `ItemList` / `DefinedTerm` / `SoftwareApplication`). Stack more for richer SERP results.

## Universal blocks (every page)

### 1. Organization

```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "{Brand Name}",
  "url": "https://{domain}",
  "logo": "https://{domain}/logo.png",
  "sameAs": [
    "https://linkedin.com/company/{handle}",
    "https://twitter.com/{handle}",
    "https://github.com/{handle}",
    "https://crunchbase.com/organization/{handle}"
  ]
}
```

Notes:
- `sameAs` is critical — these external links validate the entity to Google. Include every authoritative profile the brand has.
- Replace placeholders. If a profile doesn't exist, omit it (don't put a fake URL).

### 2. BreadcrumbList

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://{domain}/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Resources",
      "item": "https://{domain}/cases/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "{Page category, e.g., Comparison}",
      "item": "https://{domain}/cases/{slug}"
    }
  ]
}
```

The breadcrumb visible in the page must match this schema exactly.

---

## Page-type primary schemas

### 3. Article (every editorial page should wrap with this)

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "{H1 text, max 110 chars}",
  "description": "{meta description}",
  "image": ["https://{domain}/og/{slug}.png"],
  "author": {
    "@type": "Person",
    "name": "{Author Name}",
    "url": "https://{domain}/authors/{author-slug}",
    "jobTitle": "{Author Job Title}",
    "sameAs": [
      "https://linkedin.com/in/{author-handle}"
    ]
  },
  "datePublished": "{YYYY-MM-DD}",
  "dateModified": "{YYYY-MM-DD}",
  "publisher": {
    "@type": "Organization",
    "name": "{Brand Name}",
    "logo": {
      "@type": "ImageObject",
      "url": "https://{domain}/logo.png"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://{domain}/cases/{slug}"
  }
}
```

Required: `headline`, `image`, `author`, `datePublished`, `publisher`. Without these, Google won't grant Article rich results.

### 4. FAQPage (use whenever the page has a FAQ block — every page should)

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "{Question 1 verbatim}",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "{Answer 1 verbatim, can include simple HTML}"
      }
    }
  ]
}
```

**Critical**: `name` and `text` must be **verbatim identical** to the visible FAQ block on the page. Even a one-character difference can void the rich result.

### 5. HowTo (use for how-to pages and any page with a "Quick Start" steps block)

```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "{Title of the how-to}",
  "description": "{One-sentence summary}",
  "totalTime": "PT15M",
  "step": [
    {
      "@type": "HowToStep",
      "position": 1,
      "name": "{Step 1 short title}",
      "text": "{Step 1 detailed instruction}"
    },
    {
      "@type": "HowToStep",
      "position": 2,
      "name": "{Step 2 short title}",
      "text": "{Step 2 detailed instruction}"
    }
  ]
}
```

`text` field must match the step's body in the visible page.

### 6. ItemList (use for "Best X Alternatives" / "Top N Tools" pages)

```json
{
  "@context": "https://schema.org",
  "@type": "ItemList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@type": "SoftwareApplication",
        "name": "{Tool 1}",
        "url": "https://{tool-1-domain}",
        "applicationCategory": "BusinessApplication"
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@type": "SoftwareApplication",
        "name": "{Tool 2}",
        "url": "https://{tool-2-domain}",
        "applicationCategory": "BusinessApplication"
      }
    }
  ]
}
```

### 7. DefinedTerm (use for "What is X" concept pages)

```json
{
  "@context": "https://schema.org",
  "@type": "DefinedTerm",
  "name": "{The term being defined}",
  "description": "{Concise definition, 1-2 sentences}",
  "inDefinedTermSet": {
    "@type": "DefinedTermSet",
    "name": "{Glossary or topic name}"
  }
}
```

---

## Optional richness schemas

### 8. SoftwareApplication (when a product is the subject)

```json
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "{Product Name}",
  "description": "{One-sentence value prop}",
  "applicationCategory": "BusinessApplication",
  "operatingSystem": "Web, Windows, macOS, Linux",
  "url": "https://{product-domain}",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "ratingCount": "127",
    "bestRating": "5",
    "worstRating": "1"
  }
}
```

`aggregateRating` only if the brand has real review data (G2, Capterra, internal). Never fake ratings.

### 9. Review (use inside ItemList for alternatives pages)

```json
{
  "@type": "Review",
  "itemReviewed": {
    "@type": "SoftwareApplication",
    "name": "{Tool}"
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": "4",
    "bestRating": "5"
  },
  "author": {
    "@type": "Person",
    "name": "{Author Name}"
  },
  "reviewBody": "{Short review summary}"
}
```

### 10. ImageObject (for original visualizations)

```json
{
  "@context": "https://schema.org",
  "@type": "ImageObject",
  "contentUrl": "https://{domain}/img/{filename}",
  "name": "{Descriptive name}",
  "description": "{Detailed description of what the image shows}",
  "creditText": "{Brand Name}",
  "creator": {
    "@type": "Organization",
    "name": "{Brand Name}"
  },
  "license": "https://{domain}/terms"
}
```

---

## Schema combinations by page type

| Page type | Required | Strongly recommended |
|---|---|---|
| **Comparison (vs)** | Organization, BreadcrumbList, Article | FAQPage, HowTo (for the decision steps) |
| **Alternatives** | Organization, BreadcrumbList, ItemList | Article, FAQPage, Review per item |
| **How-to** | Organization, BreadcrumbList, HowTo | Article, FAQPage |
| **What-is** | Organization, BreadcrumbList, Article, DefinedTerm | FAQPage |
| **Product page** | Organization, BreadcrumbList, SoftwareApplication, Offer | AggregateRating, Review |

---

## Validation checklist

Before delivery, mentally verify each schema block:

- [ ] Every required field present
- [ ] All URLs are absolute (`https://...`), not relative (`/...`)
- [ ] All dates in ISO 8601 (`YYYY-MM-DD`), not "Jan 5, 2026"
- [ ] Visible page content matches schema content **verbatim** (FAQ, HowTo steps especially)
- [ ] No fake data in `aggregateRating`, `Review`, or `Offer`
- [ ] `sameAs` URLs are real and live
- [ ] Author entity matches the visible author block

After deploy, the user should validate at: `https://search.google.com/test/rich-results`

---

## How to embed schemas in HTML

Each schema goes in its own `<script>` block in `<head>`:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  ...
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  ...
}
</script>
```

Don't merge multiple schemas into one block (Google parses each block independently).
