# What-Is Page Template (Concept Explainer)

> Use when targeting "what is X" or "X explained" or "X meaning" keywords. The reader is in the educational stage — building understanding before deciding whether to act.

## H1 formula

`What is {Term}? {Benefit hook or scope qualifier}`

Or for less direct framing:

`{Term} Explained: {What it does / Why it matters} for {Audience}`

Examples:
- ✅ `What is an AI Data Analyst? A Practical Guide for Enterprise Teams in 2026`
- ✅ `Text-to-SQL Explained: How AI Translates Plain English into Database Queries`
- ❌ `What is AI?` (too broad — won't rank, no qualifier)
- ❌ `Definition of Data Federation` (no audience, no benefit hook)

These pages have lower commercial intent than comparison or alternatives pages, but they're crucial for **topic authority** — they build the entity recognition that makes Google trust your site on the broader topic.

## Required H2 structure

```
H2 #1: {Term} in One Sentence (the canonical definition)
H2 #2: How {Term} Works (mechanism / architecture)
H2 #3: Why {Term} Matters (use cases / pain it solves)
H2 #4: Types / Categories of {Term} (taxonomy)
H2 #5: When to Use {Term} (and when not to)
H2 #6: How to Get Started with {Term}
H2 #7: {Term} vs Related Concepts (disambiguation)
```

Pick 5-7 from this list based on how complex the term is. For common terms, fewer H2s are fine. For multi-faceted concepts, all 7.

## H2 #1 — {Term} in One Sentence

A canonical, quotable definition. This is your **Featured Snippet bid**.

```
H2: What is {term}?

<p><strong>{Term} is a {category} that {does X} by {means Y}, primarily used for {use case Z}.</strong> {1-2 sentences of essential context.}</p>
```

Rules for the definition:
- Lead with the part-of-speech anchor: "is a {tool / method / framework / category}"
- Length: 40-60 words for the bold portion
- No marketing language — pure definition
- Avoid circular definitions (don't use the term in defining itself)
- If the term has competing definitions, pick the most widely accepted and acknowledge alternatives in a follow-up sentence

This block alone, well-written, can capture the SERP for "what is {term}".

## H2 #2 — How {Term} Works

Explain the mechanism in concrete terms. Avoid abstraction.

```
H2: How {term} works

{1 paragraph: the core mechanism in plain English.}

The typical flow:
1. **{Phase 1}:** {what happens}
2. **{Phase 2}:** {what happens}
3. **{Phase 3}:** {what happens}

{1 paragraph or diagram describing the architecture or system.}
```

If the term involves a system or workflow, **include a diagram** (this is one of the strongest places for an original visualization that gets backlinked).

For abstract concepts (e.g., "topic modeling"), use a worked example with concrete inputs and outputs.

## H2 #3 — Why {Term} Matters

Frame around the user's problem. Concrete pain points.

```
H2: Why {term} matters

{Term} addresses a specific class of problems:

- **{Problem 1}:** {what teams hit this, what it costs, how {term} helps}
- **{Problem 2}:** {scenario}
- **{Problem 3}:** {scenario}

{Closing: under what conditions {term} is worth adopting.}
```

The "what it costs" piece is critical for commercial-intent capture — readers searching the term may be evaluating a purchase even if they're using educational keywords.

## H2 #4 — Types / Categories

If the term has variants or a taxonomy, this is your differentiation section. Skip if the term is monolithic.

```
H2: Categories of {term}

{Term} comes in several distinct flavors:

### {Type 1}
{1-paragraph description.}
**Examples:** {2-3 named examples or products}
**Best for:** {use case}

### {Type 2}
{1-paragraph description.}
**Examples:** {named examples}
**Best for:** {use case}

### {Type 3}
...
```

This block is excellent for entity coverage — it lets you naturally name 6-12 specific tools or sub-concepts that Google expects to see.

## H2 #5 — When to Use (and Not Use)

A balanced section. Critical for E-E-A-T.

```
H2: When to use {term} (and when not to)

**Good fit:**
- {Scenario where it works well}
- {Scenario where it works well}
- {Scenario where it works well}

**Bad fit:**
- {Scenario where it doesn't help}
- {Scenario where simpler tools win}
- {Scenario where it's actively harmful}

{Closing: a one-sentence rule of thumb.}
```

Including the "bad fit" section is what separates a definition page from a sales page. Google's quality raters specifically look for this kind of balance.

## H2 #6 — How to Get Started

Bridge from understanding to action. Short, practical.

```
H2: How to get started with {term}

For a basic implementation:
1. **{Action 1}** — {brief detail, link to a deeper guide}
2. **{Action 2}** — {brief detail}
3. **{Action 3}** — {brief detail}

For a production setup, see our guide on {linked how-to page}.
```

This section is also a HowTo schema candidate. The linked guide is critical internal-link weight.

## H2 #7 — {Term} vs Related Concepts

Disambiguation. Many readers search for the term while actually looking for an adjacent concept.

```
H2: {Term} vs related concepts

People often confuse {term} with adjacent ideas. Here's how they differ:

- **{Term} vs {Adjacent 1}:** {1-sentence disambiguation}
- **{Term} vs {Adjacent 2}:** {1-sentence disambiguation}
- **{Term} vs {Adjacent 3}:** {1-sentence disambiguation}

For a deep comparison of {Term} vs {Adjacent 1}, see {linked comparison page}.
```

This block:
1. Captures long-tail "X vs Y" queries
2. Funnels readers to your comparison pages (internal link gold)
3. Builds topical authority by demonstrating breadth

## Schema requirements

Required:
- `Organization`
- `BreadcrumbList`
- `Article`
- `DefinedTerm` (this is the special one for definition pages)
- `FAQPage`

`DefinedTerm` schema:
```json
{
  "@context": "https://schema.org",
  "@type": "DefinedTerm",
  "name": "{Term}",
  "description": "{The canonical definition from H2 #1}",
  "inDefinedTermSet": {
    "@type": "DefinedTermSet",
    "name": "{Topic name, e.g., 'AI Data Analytics Glossary'}"
  }
}
```

## FAQ slot composition for what-is pages

1. **PAA verbatim** — almost always "What does {term} mean?" or "What is the difference between {term} and {adjacent}?"
2. **Origin/etymology** — "Where did the term {X} come from?" (only if interesting)
3. **Practical** — "How do I {do something} with {term}?"
4. **Tools** — "What tools support {term}?"
5. **Common misconception** — "Is {term} the same as {commonly confused thing}?"
6. **Career-related** (sometimes) — "Do I need to know {term} for {role}?"

## Featured Snippet target

What-is pages have the highest snippet capture rate of any page type. Two main targets:

**Definition snippet** (paragraph format):
```
H2: What is {term}?
<p><strong>{40-60 word canonical definition.}</strong></p>
```

**List snippet** (when the SERP shows a list):
```
H2: What are the types of {term}?
<ul>
  <li>{Type 1}: {one-line description}</li>
  <li>{Type 2}: {one-line description}</li>
  <li>{Type 3}: {one-line description}</li>
</ul>
```

## Information gain on what-is pages

This is the trickiest type for info gain because the topic is well-known by definition. Differentiation comes from:
- **Original framework**: a named taxonomy you've coined ("the 4 layers of {term}")
- **Original diagram**: a visualization of how the concept works that's clearer than competitors'
- **Specific examples**: real-world use cases with named companies and concrete numbers
- **Practitioner perspective**: "what we learned from deploying {term} across 50 customers"

If you can't bring at least one of these, the page will be a dupe and won't rank.

## Common failure modes (watch for)

- Definition is circular ("an AI data analyst is a data analyst that uses AI")
- All sections are abstract, no concrete examples → won't rank past existing Wikipedia/Investopedia entries
- Missing "When not to use" → reads as marketing
- No disambiguation section → leaves long-tail traffic on the table
- DefinedTerm schema missing → loses a key Rich Result eligibility
- Information gain unclear → page disappears under existing authoritative entries
