# Keyword Placement & Density Rules

> Where to put primary and long-tail keywords. Hit every required slot, and stay under the density caps. Both stuffing and under-coverage hurt rankings.

## The placement table

| Position | Primary keyword | Long-tail keywords |
|---|---|---|
| `<title>` | ✅ Required, in first half | 1 long-tail |
| `<meta description>` | ✅ Required | 1-2 long-tails |
| H1 | ✅ Required | — |
| URL slug | ✅ Required | — |
| Meta subtitle (under H1) | Optional | 1 long-tail |
| First 100 words of body | ✅ Required | 1 long-tail |
| TL;DR — Problem line | ✅ Required | 1 long-tail |
| Featured Snippet capture block (H2 + answer) | ✅ Required | — |
| Before / After two-column | — | 1-2 long-tails |
| First H2 heading | ✅ Required | — |
| Other H2 headings | — | **Each H2 embeds 1 long-tail** |
| First sentence under each H2 | — | Surface naturally |
| Image filenames | ✅ Required (1+ image) | Each image filename includes 1 long-tail |
| Image alt text | — | 1-2 alts include long-tails |
| FAQ questions | — | **Each FAQ question embeds 1 long-tail** |
| FAQ answers | — | Surface naturally |
| Related Guides anchor text | — | Long-tail-rich anchors |
| Methodology block | Optional | — |

---

## Density caps (hard limits)

- **Primary keyword**: 5-8 occurrences across the entire page. **Above 8 = stuffing penalty.**
- **Each long-tail**: 2-3 occurrences. Above 4 starts looking spammy.
- **Total keyword density** (primary + long-tail count / total word count): keep under 2%.

When in doubt, swap to a **synonym, variant, or related entity** instead of the exact phrase. Google's BERT and MUM models reward semantic richness over exact-match repetition.

---

## Synonym & variant strategy (semantic SEO)

For every primary keyword, build a "synonym ring" and rotate through it. Example for `AI data analyst`:

| Original | Variants & synonyms |
|---|---|
| AI data analyst | AI-powered data analyst, AI analytics tool, automated data analysis tool, AI for analytics, machine learning data analyst, data analysis AI, professional analyst AI |

For every long-tail, do the same:

| Long-tail | Variants |
|---|---|
| complex SQL queries | complex SQL problems, multi-join SQL, 500+ line SQL, advanced SQL workloads |
| multi-source federation | cross-source queries, federated queries, cross-database joins |

In a 2000-word page, the primary keyword appears 5-8 times, but the synonym ring appears another 8-15 times. This is the signal Google uses to judge semantic depth.

---

## The entity coverage rule

Beyond keywords, the page must cover **80%+ of the semantic entity list** built in Phase 2 research. Entities are:
- Technical concepts in the topic (SQL, ETL, semantic layer)
- Named platforms / tools (Snowflake, Databricks, Power BI)
- Roles (data analyst, analytics engineer)
- Use cases (dashboards, ad-hoc queries, forecasting)

Distribute these across H2 bodies, FAQs, and the Methodology block. They establish topical depth without ever hitting density caps because they're not the target keyword.

---

## URL slug rules

- All lowercase
- Hyphens (not underscores) as separators
- Includes primary keyword
- Under 60 chars
- No stop words if avoidable (`a`, `the`, `for`, `of`)
- No year unless the page is explicitly time-bound (then use it: `best-julius-alternatives-2026`)

✅ `julius-vs-hex-vs-infinisynapse-complex-queries`
✅ `best-julius-alternatives-enterprise-2026`
❌ `the-best-AI-tools-for-data-analysis-in-2026-comparison`
❌ `julius_vs_hex` (underscores)

---

## Self-check before delivery

Run through:

- [ ] Primary keyword appears in: title, description, H1, URL slug, first 100 words, TL;DR Problem, first H2, image filename
- [ ] Primary keyword count: 5-8 (no more)
- [ ] Each long-tail keyword count: 2-3
- [ ] Each H2 (except #1) embeds at least one long-tail naturally
- [ ] Each FAQ question embeds at least one long-tail
- [ ] At least one image filename includes a long-tail
- [ ] Synonym ring used (primary keyword's variants appear 8+ times)
- [ ] Entity list coverage: ≥ 80% of Phase 2 entity list appears somewhere on the page
- [ ] No paragraph reads like keyword stuffing (test: read aloud — does it sound natural?)

If a placement reads forced ("contains the keyword but the sentence is awkward"), rewrite. Awkward placements hurt user signals (bounce rate, dwell time), which Google now reads as ranking input.
