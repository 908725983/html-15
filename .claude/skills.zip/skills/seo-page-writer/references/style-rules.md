# Style Rules — Voice, Sentences, Banned Phrases

> Apply these to every paragraph. The goal: prose that reads like a senior practitioner wrote it, not a content-mill SEO writer.

## The seven core principles

### 1. Numbers > adjectives

Replace every adjective claim with a quantified one.

✅ `accuracy drops to 50-65% on 500+ line SQL problems`
❌ `accuracy is significantly lower for complex queries`

✅ `12-hour hand-written query at $1,200-$1,800 senior-analyst loaded cost`
❌ `expensive to do manually`

If you can't find a number, find a specific scenario instead:

✅ `joining a Snowflake warehouse with a Postgres OLTP and a Mongo collection`
❌ `multi-source data scenarios`

### 2. Source > assertion

Every quantitative claim needs an attached source. No exceptions.

✅ `accuracy stays above 90% (Source: 2026 Q1 internal benchmark, n=50 customer queries)`
✅ `Julius shows ~1.5M monthly visits as of early 2026 (Source: Similarweb)`
❌ `accuracy is industry-leading`
❌ `most popular tool in the category`

If the user didn't provide a number you need, do NOT invent one. Insert a placeholder:
```
[NEEDS DATA: user to confirm accuracy benchmark]
```

### 3. Honesty > marketing

Every comparison page must include at least one honest concession where a competitor wins. This is not a weakness — it's the trust signal that lets the rest of the claims stick.

✅ `For teams already standardized on Snowflake with strong notebook collaboration needs, Hex is a better fit than InfiniSynapse.`
✅ `If your analytical backlog is mostly under 100-line SQL, Julius is the lowest-friction choice.`

End every comparison H2 with a "so who should pick this" line. Even if the answer is "not us, in this case" — Google's E-E-A-T signals reward this honesty heavily.

### 4. Scenarios > features

Lead with the user's situation, then connect to the feature.

✅ `When you need to join a Snowflake warehouse with a Postgres OLTP table and a Confluence doc — and your security policy disallows cloud upload — InfiniSynapse's local-execution federation is the architecture that fits.`

❌ `InfiniSynapse offers powerful multi-source federation with on-prem deployment.`

The first version names a real workflow. The second is generic capability marketing.

### 5. Short paragraphs

- Maximum 4 lines per paragraph
- Maximum 2 sentences per paragraph (often 1 is enough)
- Long content → use bullet lists, not run-on paragraphs
- Use a `<strong>` highlight every 2-3 paragraphs to give scannability

Why: 60%+ of readers scan first, read second. Long paragraphs guarantee they bounce.

### 6. Second person, active voice

Always `your team` / `you`, never `users` / `customers` / `one`.

✅ `If your data lives in one warehouse, Hex or Julius both work.`
❌ `If a user's data is consolidated in a single warehouse, either Hex or Julius would be a viable option.`

Active voice over passive:

✅ `InfiniSynapse processes data on the user's local machine.`
❌ `Data is processed on the user's local machine by InfiniSynapse.`

### 7. End-of-section judgment

Every H2 closes with one short sentence that gives the reader a takeaway decision rule.

✅ `If your analytical backlog is dominated by simple questions, Julius is the lowest-friction choice. If it is dominated by complex multi-join queries, InfiniSynapse is architecturally better suited.`

This is the signal that this page is helpful, not just informative. It also produces snippet-ready content for Google.

---

## Banned phrases (ctrl-F before delivery)

These appear constantly in low-quality SEO content and signal to Google (and readers) that the page is generic. Remove every instance.

| Banned | Replace with |
|---|---|
| industry-leading | a specific number or third-party rank |
| best-in-class | a measurable comparison |
| cutting-edge | the actual technology name |
| seamless / seamlessly | a specific workflow description |
| revolutionary / game-changing | what specifically changed |
| robust | a quantified capability |
| state-of-the-art | a specific feature or benchmark |
| user-friendly | a concrete UI behavior |
| comprehensive | enumerate what's covered |
| powerful | a specific capability + number |
| solution (for X) | name the product or method |
| leverage | use |
| utilize | use |
| in today's fast-paced world / in the modern era | delete the whole phrase |
| as we all know | delete |
| the fact that | delete or "that" |
| at the end of the day | delete |
| dive deep / deep dive | examine / cover |
| game-changer | name the specific change |

---

## Sentence patterns to use

### "Specific Setup → Result" pattern

`{Specific scenario}: {specific outcome with number}`

`On 1,200-line cross-source SQL with predicate pushdown disabled: Julius produces plausible-looking output 50% of the time, accurate output 28% of the time, and timeouts 22%. (Source: 2026 Q1 internal test, n=50.)`

### "Three named alternatives" pattern (in body lists)

`<strong>{Product A}:</strong> {differentiator with number}. {who it fits}.
<strong>{Product B}:</strong> {differentiator with number}. {who it fits}.
<strong>{Product C}:</strong> {differentiator with number}. {who it fits}.`

### "If X, then Y" judgment closer

`If {specific condition}, {Product A} fits. If {other condition}, {Product B} is the better choice.`

### "Honest concession" sentence

`{Competitor} {wins on this dimension} when {specific situation}. {Our product} is not designed for this use case.`

---

## Voice calibration by audience

If the user specifies the audience, adjust:

| Audience | Voice notes |
|---|---|
| Data engineers / analysts | Technical precision, named tools, SQL examples, latency numbers |
| Product / business leaders | ROI framing, time-to-value, headcount math, total cost |
| Developers (general) | Code snippets, API examples, integration patterns |
| Non-technical buyers | Analogies, no jargon without explanation, outcomes over features |

If unspecified, default to "informed practitioner" — assumes basic familiarity with the domain but explains anything proprietary.

---

## A 60-second draft test

After writing each section, re-read aloud. Catch and fix:
- Any sentence longer than ~25 words → split
- Any paragraph longer than 4 lines → split or bullet
- Any adjective claim without a number → quantify or delete
- Any banned phrase → replace
- Any "we" claim without a source → cite or remove
- Any feature mentioned without a user scenario → frame around the user

If a section passes the 60-second test, move on. If not, rewrite before continuing.
