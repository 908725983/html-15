# How-To Page Template

> Use when targeting a "how to {do X}" or "how to {do X} with {Product}" keyword. The reader has a specific task in mind and wants step-by-step guidance.

## H1 formula

`How to {Specific Action} with {Product / Method} {Optional: Outcome qualifier}`

Examples:
- ✅ `How to Run Cross-Database SQL with InfiniSynapse Without Writing ETL`
- ✅ `How to Set Up Customer Cohort Analysis in Snowflake with AI`
- ❌ `How to Use InfiniSynapse` (vague — no specific action)
- ❌ `Tutorial: Data Analysis` (no product, no specific outcome)

The "outcome qualifier" matters because it differentiates your page from generic tutorials. "Without writing ETL" or "in under 10 minutes" makes the page rank for the qualified long-tail.

## Required H2 structure

```
H2 #1: What You'll Need (prerequisites)
H2 #2: Step 1 — {First concrete action}
H2 #3: Step 2 — {Next action}
H2 #4: Step 3 — {Next action}
... up to ~7 steps total
H2 #N: Verifying It Works
H2 #N+1: Common Issues and How to Fix Them
H2 #N+2: What to Do Next
```

Step count: 5-7 steps is typical. Under 5 steps reads as too thin; over 8 overwhelms.

## H2 #1 — What You'll Need

Prerequisites listed clearly so readers can check before investing time.

```
Before starting, you'll need:

- **{Tool or account 1}:** {free / paid tier? specific version?}
- **{Data or input 2}:** {format, size}
- **{Skill or background 3}:** {basic SQL? Python? none required?}
- **Time required:** {realistic estimate, e.g., "about 15 minutes"}

If you don't have {item X} yet, here's how to {get it / set it up}: {1-line pointer to a separate guide}.
```

The time estimate is critical — it's a Featured Snippet candidate and signals to Google that this is a HowTo (Schema-friendly).

## H2 #2 to N — Step-by-Step Sections

Each step gets its own H2 (not a sub-bullet). This is unusual for blog posts but optimal for HowTo schema and SERP capture.

Each step structure:
```
H2: Step N — {Action verb} {object}

{1-paragraph explanation of what this step accomplishes and why}

{Concrete instructions:
- Click X
- Type Y
- Run Z}

{Code block, screenshot reference, or example output if applicable}

{Optional: brief "what if it doesn't work" note}
```

### Step writing rules

- **Action verb at start**: `Connect`, `Configure`, `Run`, `Verify`, `Export`
- **Specific objects**: not "the database" but "your Snowflake warehouse"
- **Show, don't summarize**: if the step involves UI clicks or commands, write them out
- **Include expected output**: "You should see {X}. If you see {Y} instead, see the Common Issues section."

### Code blocks

If the how-to involves code:
```html
<pre><code class="language-sql">
SELECT customer_id, SUM(order_total) as ltv
FROM orders
WHERE order_date >= '2025-01-01'
GROUP BY customer_id
</code></pre>
```

Add `language-{lang}` class even though the page may not have syntax highlighting — it's a hint for accessibility tools and future highlighting.

### Visualization in steps

For UI-heavy how-tos, include screenshots (or inline SVG mockups). Each screenshot:
- Has clear alt text describing the action
- Has a 1-line caption
- Is referenced from the prose ("In the dialog shown below, click X")

## H2 #N — Verifying It Works

After the last step, give the reader a way to confirm success without ambiguity.

```
H2: Verifying It Works

Run this final check:

{Specific verification action: command, query, UI screen}

You should see:
- {Specific output 1}
- {Specific output 2}

If you see {alternate output}, jump to the Common Issues section.
```

This block is critical because it converts "I followed the steps" into "I confirmed it worked." That's the metric the user actually cares about.

## H2 #N+1 — Common Issues and How to Fix Them

A troubleshooting section. Format as Q-and-A or as named-error sections:

```
H2: Common Issues and How to Fix Them

### Error: {Specific error message or symptom}
**Cause:** {What's actually wrong}
**Fix:** {Specific resolution steps}

### Error: {Another specific error}
**Cause:** {What's actually wrong}
**Fix:** {Specific resolution steps}
```

This section is **highly Featured-Snippet-friendly** for related troubleshooting queries (the user might search for the error itself, not the original how-to).

Aim for 3-5 of the most common errors. If you don't know what they are, ask the user — they'd know from support tickets or community forums.

## H2 #N+2 — What to Do Next

A short closer that points to logical follow-ups.

```
Now that you've {completed the action}, you can:

- {Next-level task 1} — see {linked guide}
- {Next-level task 2} — see {linked guide}
- {Related advanced topic} — see {linked guide}
```

This serves dual purposes: improves dwell time and builds the topic cluster (each linked guide is internal).

## Schema requirements

Required:
- `Organization`
- `BreadcrumbList`
- `HowTo` (this is the primary schema for this page type)
- `Article` (for E-E-A-T)
- `FAQPage`

The `HowTo` schema must include:
- `name` — matches H1
- `description` — matches meta description
- `totalTime` — in ISO 8601 duration format (e.g., `PT15M` for 15 minutes)
- `step[]` — one entry per H2 step, with `name` and `text` matching the visible step block

## FAQ slot composition for how-to pages

1. **PAA verbatim** — usually "How long does it take to {do X}?" or "Can I {do X} without {prerequisite}?"
2. **Skill prerequisite** — "Do I need to know {SQL / Python / X} for this?"
3. **Cost** — "Is this free? What's the pricing?"
4. **Alternative method** — "Is there a way to do this without {Product}?"
5. **Scale concern** — "Does this work for {large data / many users}?"
6. **Edge case** — "What if my {data / setup} is different?"

## Featured Snippet target

How-to pages have two strong snippet targets:

**Numbered list snippet** (most common):
```
H2: How to {do X} with {Product}
<ol>
  <li>{Step 1 short summary}</li>
  <li>{Step 2 short summary}</li>
  <li>{Step 3 short summary}</li>
  <li>{Step 4 short summary}</li>
</ol>
```

**Time-to-completion snippet**:
```
H2: How long does it take to {do X}?
<p><strong>{The action} takes about {X minutes} to set up: {brief breakdown}.</strong></p>
```

Pick whichever matches the SERP.

## Common failure modes (watch for)

- Steps too generic ("Connect to your database") → spell out which database, which connection method, what the dialog looks like
- Missing prerequisites → readers get halfway through and bail
- No verification step → readers can't tell if they succeeded
- No troubleshooting → readers Google the error and never come back
- Steps don't match HowTo schema verbatim → schema invalidates
- Time estimate is vague or missing → loses Featured Snippet eligibility
