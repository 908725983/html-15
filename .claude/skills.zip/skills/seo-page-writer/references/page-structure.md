# Page Structure — 17 Canonical Blocks

> Every SEO page produced by this skill follows this exact block order. Skipping or reordering blocks breaks the layout, the E-E-A-T flow, or the Featured Snippet capture logic.

## Block order

```
1.  <head> — meta + schema + critical CSS
2.  <nav> — top navigation
3.  Breadcrumb
4.  Badges (product / category)
5.  H1
6.  Meta subtitle (the one-sentence summary under H1)
7.  Author block (E-E-A-T)
8.  Table of Contents (long pages only)
9.  TL;DR box (Problem / Solution / Result)
10. Featured Snippet capture block
11. Before / After two-column
12. Body H2s (4-6 of them) — type-specific structure
13. Original visualization (chart / diagram)
14. Quick Start / Steps
15. CTA box
16. FAQ
17. Methodology / About this guide
18. Related Guides (≥ 5 internal links)
19. <footer>
```

(17 content blocks plus head and footer.)

---

## Block-by-block specs

### Block 1 — `<head>`

Must contain, in this order:
- `<meta charset>` and `<meta viewport>`
- `<title>` — 40-60 chars, primary keyword first, ends with `| BrandName`
- `<meta name="description">` — 150-160 chars, includes primary keyword + 1-2 long-tails
- `<meta name="robots" content="index, follow">`
- `<meta name="author" content="...">`
- Open Graph block (`og:title`, `og:description`, `og:type=article`, `og:url`, `og:image`)
- `<meta name="twitter:card" content="summary_large_image">`
- `<link rel="canonical">` — absolute URL, required
- `<link rel="preconnect">` for fonts
- All JSON-LD `<script type="application/ld+json">` blocks (see `schema-library.md`)
- Inline critical CSS

### Block 2 — Navigation

Sticky top nav. Logo + 3-5 links + 1 CTA button. Standard pattern — see scaffold.

### Block 3 — Breadcrumb

```html
<nav class="breadcrumb">
  <a href="/">Home</a><span>›</span>
  <a href="/cases">Resources</a><span>›</span>
  Comparison
</nav>
```

Always paired with `BreadcrumbList` schema in `<head>`.

### Block 4 — Badges

Two pill-shaped badges directly above H1:
- Brand badge (colored, e.g., `InfiniSynapse`)
- Category badge (neutral, e.g., `Comparison` / `Guide` / `Alternatives`)

### Block 5 — H1

- Exactly one `<h1>`
- 50-70 chars, contains primary keyword naturally
- Formula by page type:
  - Comparison: `A vs B vs C: Which X for Y`
  - Alternatives: `Best X Alternatives for Y in {year}`
  - How-to: `How to {do X} with {Y}`
  - What-is: `What is X? {Benefit hook}`
- ✅ Specific + benefit: `Julius AI vs Hex vs InfiniSynapse: Which AI Data Analyst Wins for Complex Queries`
- ❌ Vague: `Best AI Tools for Data Analysis`

### Block 6 — Meta subtitle

One or two sentences directly under H1. Tells the reader who this page is for and what they get. Must include 1 long-tail keyword. Visually muted (60-70% opacity).

### Block 7 — Author block (E-E-A-T, mandatory)

```html
<div class="author-meta">
  <img src="/authors/{slug}.jpg" alt="{Name}" width="44" height="44">
  <div class="author-info">
    <a href="/authors/{slug}">{Name}</a> · {Job Title}
    <p class="author-bio">{One-line credential, e.g., "10 years enterprise data analysis, formerly at X"}</p>
  </div>
  <div class="dates">
    <span>Published: {YYYY-MM-DD}</span>
    <span>Last Updated: {YYYY-MM-DD}</span>
  </div>
</div>
```

Required:
- Real name (not a pen name)
- Headshot image
- One-line credential (years + key role)
- Link to `/authors/{slug}` page
- Both Published and Last Updated dates

The same author info must appear in the `Article` schema's `author` field.

### Block 8 — Table of Contents (only if page > 1500 words)

Sticky-on-desktop or collapsible-on-mobile anchor list. One entry per H2.

### Block 9 — TL;DR box

Three-line structure, no exceptions:
```html
<div class="tldr">
  <div class="tldr-label">TL;DR</div>
  <ul>
    <li><strong>Problem:</strong> {one sentence on the user's pain or market state}</li>
    <li><strong>Solution:</strong> {one sentence on what this page proposes}</li>
    <li><strong>Result:</strong> {one sentence on what the reader will walk away with}</li>
  </ul>
</div>
```

The Problem line should include the primary keyword.

### Block 10 — Featured Snippet capture block (mandatory, often skipped — don't)

This is a dedicated block right after TL;DR, designed specifically to win the Featured Snippet position. Two valid formats — pick based on what the SERP shows.

**Format A — Paragraph snippet** (when the SERP's snippet is a paragraph):
```html
<h2>{Question form of the keyword, e.g., "What is the best AI data analyst for complex queries?"}</h2>
<p class="snippet-answer"><strong>{40-60 word direct answer. Lead with the conclusion. No fluff.}</strong></p>
```

**Format B — List/steps snippet** (when the SERP's snippet is a list):
```html
<h2>{How to / Steps to ...}</h2>
<ol class="snippet-list">
  <li>{Step 1, action verb start}</li>
  <li>{Step 2}</li>
  <li>{Step 3}</li>
</ol>
```

Rules:
- The H2 must be a question or "How to" phrase
- The answer comes immediately, no preamble paragraph
- Paragraph answer is 40-60 words, hard limit
- Use `<strong>` to mark the core answer (some SERP parsers prioritize bolded text)

### Block 11 — Before / After two-column

```html
<div class="ba-grid">
  <div class="ba-card ba-before">
    <div class="ba-label">Before</div>
    <div class="ba-text">{Pain state, 2-3 sentences}</div>
  </div>
  <div class="ba-card ba-after">
    <div class="ba-label">After — with {product}</div>
    <div class="ba-text">{Solved state, 2-3 sentences. Must mirror the Before structure.}</div>
  </div>
</div>
```

Mirror discipline: if Before talks about problem X, After must address X (not Y).

### Block 12 — Body H2s

4-6 H2s. The exact structure depends on page type — see the page-type templates (`comparison-template.md`, `alternatives-template.md`, etc.).

**Universal "three-part recipe" for every H2 body:**

1. Opening sentence — point to what this section will show
2. `<ul>` list — each `<li>` starts with `<strong>{entity name}:</strong>` and contains specific numbers, dates, or named scenarios
3. Closing sentence — explicit "so who/when should pick this" judgment

✅ Good: "InfiniSynapse: purpose-built for 500-2,000 line problems via InfiniSQL iterative execution. Customer-validated accuracy stays above 90% at complexity tiers where monolithic-generation tools drop to 50-65%."

❌ Bad: "InfiniSynapse: industry-leading accuracy on complex queries."

Every quantitative claim in body H2s needs an inline source. Either a parenthetical:
```
(Source: 2026 Q1 internal benchmark, n=50)
```
or a footnote-style link to a citation block.

### Block 13 — Original visualization (mandatory, ≥ 1 per page)

At least one of:
- Self-run benchmark chart (bar, line)
- Decision tree / flowchart (when to pick what)
- Architecture comparison diagram
- Comparison matrix (visual, not just an HTML table)

Implementation:
- Inline SVG preferred (sharp at any zoom, indexable)
- Otherwise WebP with `<img loading="lazy" width="..." height="...">` (CLS prevention)
- Filename includes keywords: `julius-vs-hex-accuracy-benchmark-2026.svg`
- Alt text describes the data, not just the chart type: ✅ `Bar chart: Julius AI 52%, Hex 71%, InfiniSynapse 92% accuracy on 500+ line SQL queries` ❌ `Accuracy chart`
- Caption below the image (1 line, visible)
- Pair with `ImageObject` schema in `<head>`

If the user did not provide data for an original chart, do NOT fabricate. Insert a placeholder block:
```html
<!-- TODO: Original benchmark chart needed. User to provide data. -->
<div class="placeholder">[Original chart placeholder — user to provide benchmark data]</div>
```
And flag in delivery.

### Block 14 — Quick Start / Steps

3 steps ideal, max 5. Each step:
```html
<div class="step-box">
  <span class="step-num">1</span>
  <strong>{Action verb + specific object}</strong>
  <p>{2-4 sentences. Concrete, not generic. Include numbers if possible.}</p>
</div>
```

Step content **must match the `HowTo` JSON-LD verbatim** (Google penalizes mismatch).

### Block 15 — CTA box

```html
<div class="cta-box">
  <h3>{One-sentence value prop}</h3>
  <p>{One-sentence capability statement}</p>
  <a href="{primary CTA URL}" class="cta-btn">{Action verb} →</a>
</div>
```

CTA copy uses action verbs: `Start Free →` / `Get a Demo →` / `Try Now →` / `See Pricing →`.

### Block 16 — FAQ (4-6 items)

Composition rules:
1. **At least 1 must be a verbatim PAA question** captured from SERP research (Phase 2)
2. **At least 1 reverse-funnel question**: "When NOT to use {product}?" or "What are {product}'s limitations?"
3. Standard slots to fill the rest:
   - Integration / compatibility ("Can I use X with Y?")
   - Adjacent competitor ("What about {other tool}?")
   - ROI / cost ("Is X worth it for a small team?")
   - Proof ("Do you have concrete examples?")

```html
<div class="faq-item">
  <div class="faq-q">{Question — verbatim from PAA where possible}</div>
  <div class="faq-a">{2-4 sentence answer. First 60 words are critical (PAA grabs them).}</div>
</div>
```

FAQ items must match the `FAQPage` schema entries exactly — same question text, same answer text.

### Block 17 — Methodology / About this guide (E-E-A-T, mandatory)

Tail-end transparency block. Skip and you sacrifice trust signals.

```html
<div class="methodology">
  <h2>About this {guide / comparison}</h2>
  <p><strong>Last updated:</strong> {YYYY-MM-DD}</p>
  <p><strong>Methodology:</strong> {1-3 sentences on how data was gathered, tools tested, sample sizes}</p>
  <p><strong>Conflict of interest:</strong> {disclosure, e.g., "We are the {product} team. All benchmark data and methodology are documented at {link} and reproducible by readers."}</p>
  <p><strong>Update cadence:</strong> {e.g., "Reviewed quarterly. Pricing and feature data refreshed every 90 days."}</p>
</div>
```

### Block 18 — Related Guides

≥ 5 internal links forming the topic cluster. Card-grid layout:
```html
<div class="related">
  <a href="/cases/{slug}">{Target page H1, used verbatim as anchor}</a>
  ...
</div>
```

Anchor text rules:
- Use the target page's H1 (or a keyword-rich shortened version)
- Never use "click here" / "read more"
- Mix exact-match, partial-match, and natural-phrase anchors

In addition to this end-block, weave **3+ contextual internal links into the body H2 prose** (not just at the end).

### Block 19 — Footer

Standard 4-column footer: brand blurb + Product / Resources / Company columns. Bottom line with copyright + tagline.

---

## Mobile breakpoint requirements

At 720px width:
- `.ba-grid`, `.related`, `.footer-grid` collapse to single column
- H1 reduces to ~1.75rem
- Nav links collapse, CTA button stays
- Padding tightens

The scaffold has these breakpoints baked in. Don't remove them.

---

## What "complete" looks like

A page is complete when:
- Every block in this list is present (or explicitly skippable for the page type)
- The audit checklist (`audit-checklist.md`) passes 100%
- Schema validates mentally (all required fields, dates ISO, URLs absolute)
- All `[NEEDS INPUT: ...]` and `TODO:` markers are surfaced in the delivery note
