# Audit Checklist — Run Before Delivery

> Hard gate. Do not present the page until every item passes. If anything fails, fix and re-audit.

## Section A — Head & Meta

- [ ] `<title>` is 40-60 characters (count them)
- [ ] `<title>` has primary keyword in the first half
- [ ] `<title>` ends with `| BrandName`
- [ ] `<meta description>` is 150-160 characters
- [ ] `<meta description>` includes primary keyword + at least 1 long-tail
- [ ] `<meta description>` makes a "what you'll get" promise (not just a teaser)
- [ ] `<link rel="canonical">` is present and absolute (`https://...`)
- [ ] `<meta name="robots" content="index, follow">` present
- [ ] `<meta name="author">` matches the visible author block name
- [ ] Open Graph block complete: `og:title`, `og:description`, `og:type`, `og:url`, `og:image`
- [ ] `og:image` URL is absolute and the image is 1200×630
- [ ] `<meta name="twitter:card" content="summary_large_image">` present

## Section B — Schema

- [ ] At least 5 JSON-LD blocks: `Organization`, `BreadcrumbList`, `Article`, `FAQPage`, and at least one page-type schema (`HowTo` / `ItemList` / `DefinedTerm` / `SoftwareApplication`)
- [ ] FAQPage schema present (every page should have one)
- [ ] FAQPage `name` and `text` fields **verbatim match** the visible FAQ block
- [ ] If HowTo schema present, step `text` matches visible Quick Start block
- [ ] All schema URLs are absolute, not relative
- [ ] All schema dates in ISO 8601 (`YYYY-MM-DD`)
- [ ] Article schema includes `author`, `datePublished`, `dateModified`, `publisher`
- [ ] Each schema is in its own `<script type="application/ld+json">` block (not merged)
- [ ] No fake data in `aggregateRating`, `Review`, `Offer`

## Section C — Content Structure (the 17 blocks)

- [ ] Exactly one `<h1>`
- [ ] H1 is 50-70 characters
- [ ] H1 contains primary keyword naturally
- [ ] Meta subtitle directly follows H1
- [ ] Author block present with: name, headshot, credentials, link to /authors/, both Published and Last Updated dates
- [ ] Author block dates match `Article` schema dates exactly
- [ ] TOC present if page > 1500 words
- [ ] TL;DR has all 3 lines: Problem, Solution, Result
- [ ] TL;DR Problem line includes primary keyword
- [ ] **Featured Snippet block present** with question-form H2 + 40-60 word answer (or list format)
- [ ] Before / After two-column block has mirrored structure
- [ ] 4-6 body H2s
- [ ] Each body H2 follows the three-part recipe (opening + list + closing judgment)
- [ ] Every quantitative claim has an inline source
- [ ] At least 1 original visualization (chart / diagram / matrix)
- [ ] Visualization has descriptive alt text and caption
- [ ] Quick Start / Steps block present with 3-5 steps
- [ ] CTA block present with action-verb button
- [ ] **FAQ has 4-6 items**
- [ ] At least 1 FAQ uses verbatim PAA question from SERP research
- [ ] At least 1 FAQ is reverse-funnel ("when not to use" / limitations)
- [ ] **Methodology / About block present** with: last updated date, methodology, conflict of interest, update cadence
- [ ] At least 5 Related Guides links
- [ ] At least 3 contextual internal links woven into body H2 prose
- [ ] Footer present with brand blurb + 3 link columns + copyright

## Section D — Keyword Coverage

- [ ] Primary keyword appears 5-8 times total (count it)
- [ ] Primary keyword in: title, description, H1, URL slug, first 100 words, TL;DR Problem, first H2, at least 1 image filename
- [ ] Each long-tail keyword appears 2-3 times
- [ ] Each H2 (except #1) embeds at least one long-tail
- [ ] Each FAQ question embeds at least one long-tail
- [ ] Synonym ring used (variants of primary keyword appear 8+ times)
- [ ] Entity list coverage ≥ 80% of Phase 2 entity list
- [ ] No paragraph is keyword-stuffed (read aloud test)

## Section E — E-E-A-T Signals

- [ ] Real author name (not a pen name like "John Doe" or "Editorial Team")
- [ ] Author has a one-line credential (years + key role)
- [ ] Author block links to a real `/authors/{slug}` page (or note this is required to create)
- [ ] Every data point on the page has a source
- [ ] Methodology block disclosed
- [ ] Conflict-of-interest disclosed (especially on comparison/alternatives pages)
- [ ] At least one honest concession to a competitor (where they win)
- [ ] No anonymous superlatives ("the best", "the most popular") without a citation

## Section F — Style

- [ ] No banned phrases (industry-leading, best-in-class, seamless, robust, leverage, utilize, etc.) — see `style-rules.md`
- [ ] No paragraph longer than 4 lines
- [ ] No sentence longer than ~25 words (with rare exception)
- [ ] Second-person voice ("your team")
- [ ] Active voice (not passive)
- [ ] Every H2 ends with a "so who should pick this" judgment line
- [ ] Numbers used over adjectives wherever possible

## Section G — Technical / Performance

- [ ] HTML is a single self-contained file
- [ ] CSS is inline in `<style>` (not external)
- [ ] Only external resource is Google Fonts (acceptable; the user can self-host later)
- [ ] All `<img>` tags have `width`, `height`, `alt`, and `loading="lazy"` (except above-fold images)
- [ ] Above-fold images don't use `loading="lazy"`
- [ ] Fonts use `font-display: swap`
- [ ] Mobile breakpoints work (collapse multi-column layouts at 720px)

## Section H — 11 Hard Metrics (auto-checked by `assets/audit-page.py`)

These 11 are non-negotiable. Run `python3 assets/audit-page.py /mnt/user-data/outputs/{slug}.html` (add `--site-domain {brand-domain}` if user provided one). Every row must say PASS. Re-run after every fix until exit code is 0.

- [ ] **#1** Title length 40-60 chars
- [ ] **#2** Meta description length 150-160 chars
- [ ] **#3** Exactly one `<h1>`
- [ ] **#4** `<h2>` count ≥ 4
- [ ] **#5** `<h3>` count ≥ 1
- [ ] **#6** Canonical present AND absolute (`https://...`)
- [ ] **#7** Open Graph (`og:title`, `og:description`, `og:image`, `og:url`) + Twitter Card (`twitter:card`) all present and non-empty
- [ ] **#8** Every `<img>` has a non-empty `alt`
- [ ] **#9** Internal links ≥ 5 (root-relative `/path`, in-page `#anchor`, or same-domain absolute)
- [ ] **#10** External links ≥ 1 (different host, http(s))
- [ ] **#11** JSON-LD `<script type="application/ld+json">` blocks ≥ 5
- [ ] `audit-page.py` exit code is 0

If any metric cannot be satisfied (e.g. the page legitimately has no images, or the user refuses an external citation), flag the deviation in the delivery message — do not deliver silently.

## Section I — Theme

- [ ] `<html data-theme="...">` is set to `light` or `dark` based on Phase 1 input — not left as `{{THEME}}` and not blank
- [ ] All colors used render correctly in the chosen theme (spot-check: nav, body text, CTA button, footer, code blocks)
- [ ] If brand color tokens were provided, they were applied inside the matching theme block — the other theme block was left intact

## Section J — Final Pre-Delivery

- [ ] All `[NEEDS DATA]` and `TODO:` markers surfaced in delivery message
- [ ] File saved as `/mnt/user-data/outputs/{kebab-case-slug}.html`
- [ ] Slug derived from primary keyword, under 60 chars
- [ ] Delivery message lists: summary, slug used, before-deploy steps (validate schema, test mobile, run PageSpeed)

---

## Audit failure protocol

If any item fails:
1. Identify which block needs fixing
2. Fix that block specifically (don't rewrite the whole page)
3. Re-run the relevant section of the checklist
4. Only deliver after a clean pass

If a failure is structural (e.g., entire E-E-A-T author block missing because the user didn't provide author info), surface this to the user **before** delivering. Don't fake author data.

---

## Common audit failures (watch for these)

| Failure | Fix |
|---|---|
| Title > 60 chars | Tighten by removing brand name or filler words |
| H1 has no primary keyword | Rewrite H1 to include it naturally |
| FAQ doesn't match FAQPage schema | Re-paste the schema directly from the visible FAQ |
| Featured Snippet block missing | Add a question-form H2 + bolded answer right after TL;DR |
| Methodology block missing | Add it before Related Guides |
| No original chart | Either add data or insert placeholder + flag at delivery |
| Primary keyword count > 8 | Replace some occurrences with synonyms |
| Adjective claims without numbers | Quantify or remove |
| Author info skipped | Stop. Ask user for author info. Do not deliver. |
