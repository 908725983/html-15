# Comparison Page Template (A vs B / A vs B vs C)

> Use when the page targets a "vs" keyword. The reader is in the commercial-investigation stage — actively choosing between products.

## H1 formula

`{Product A} vs {Product B} vs {Product C}: Which {category} {wins for / fits / suits} {specific use case}`

Examples:
- ✅ `Julius AI vs Hex vs InfiniSynapse: Which AI Data Analyst Wins for Complex Queries`
- ✅ `Notion vs Coda vs Airtable: Which All-in-One Workspace Fits Operations Teams`
- ❌ `The Best Comparison of Notion and Coda` (no specific use case)

The "specific use case" qualifier is what makes the H1 win — it tells the reader who this comparison is for and signals to Google what the page actually answers.

## Required H2 structure

```
H2 #1: Product Positioning Summary
H2 #2: Dimension 1 — {key differentiator 1}
H2 #3: Dimension 2 — {key differentiator 2}
H2 #4: Dimension 3 — {key differentiator 3}
H2 #5: Dimension 4 — Total Cost of Ownership
(optional) H2 #6: Decision Framework — Which One Fits You
```

Pick dimensions that are **measurable and decision-critical** for the audience. For a developer-tool comparison, common dimensions:
- Query complexity ceiling / accuracy
- Multi-source / integration breadth
- Data security / deployment options
- Pricing / TCO
- Collaboration / team workflow
- Time to value / setup friction

For a SaaS-business comparison:
- Features depth in core area
- Pricing transparency
- Customer support quality
- Integrations
- Migration / lock-in cost
- Scale ceiling

## H2 #1 — Product Positioning Summary

Goal: tell the reader **who each product is built for**, not what it does.

Pattern:
```
The {N} products target adjacent but distinct market segments:
- **{Product A}** ({1-line size signal, e.g., monthly visits, customer count, raise}): {who it's built for, what kind of work}
- **{Product B}** ({1-line size signal}): {who it's built for}
- **{Product C}** ({1-line size signal}): {who it's built for}

They are not direct substitutes across the whole market. They overlap at {middle tier} and diverge at the extremes.
```

The "size signal" is critical — it lets the reader calibrate. (Don't fake numbers; use what's public from Similarweb, Crunchbase, etc.)

## H2 #2-4 — Dimensions

Each dimension follows the universal three-part recipe (from `page-structure.md`):

```
H2: Dimension N — {Dimension name}

{Opening sentence: what this dimension measures, why it matters.}

- **{Product A}:** {specific behavior + number + scenario}.
- **{Product B}:** {specific behavior + number + scenario}.
- **{Product C}:** {specific behavior + number + scenario}.

{Closing judgment: under what conditions each one is the right pick.}
```

Hard rules per dimension:
- Each bullet has at least one concrete number (accuracy %, line count, latency ms, $ amount)
- At least one bullet must be an **honest concession** where the competitor wins
- Closing line gives a clear "if X, pick Y" rule

### Worked example (good)

> **Dimension 1 — Query Complexity Ceiling**
>
> The clearest differentiator. Where each product's accuracy cliff sits:
>
> - **Julius AI:** excellent on single-table and simple-join questions (under 100 line SQL). Accuracy drops sharply past 300 lines. Not designed for 1,000+ line analytical problems; when pushed, produces plausible-looking but frequently wrong output.
> - **Hex AI:** good for medium-complexity questions within a warehouse. The analyst still owns verification; the AI is a drafting aid in a notebook. Better than Julius at complex work because the notebook structure encourages iteration.
> - **InfiniSynapse:** purpose-built for 500-2,000 line problems via InfiniSQL iterative execution. Customer-validated accuracy stays above 90% at complexity tiers where monolithic-generation tools drop to 50-65%.
>
> If your analytical backlog is dominated by simple questions, Julius is the lowest-friction choice. If it is dominated by complex multi-join queries, InfiniSynapse is architecturally better suited.

### What to avoid

- Generic capability lists ("supports SQL, Python, R")
- Marketing adjectives ("powerful", "advanced", "robust")
- Bullets without numbers
- Closing lines that say "all three are good options" — no, give a real recommendation

## H2 #5 — Total Cost of Ownership

Always include. Even if the user is on a free trial of all three, a serious comparison page calculates 1-3 year TCO.

Pattern:
```
Pricing models differ significantly:

- **{Product A}:** {free tier?} paid plans around ${X-Y}/user/month. Enterprise {custom / $Z+}.
- **{Product B}:** starts around ${X-Y}/user/month. Enterprise ${Z+}/user/month or custom.
- **{Product C}:** {pricing structure}.

For a {N}-user team, {3-year} TCO typically: A ${X}-${Y}; B ${X}-${Y}; C ${X}-${Y}. {The cost gap is paired with} {capabilities or limitations}.
```

If pricing isn't public for one product, say "custom enterprise" and explain. Don't invent.

## Optional H2 #6 — Decision Framework

A short, scannable decision tree:
```
Pick {A} if: {condition 1}, {condition 2}.
Pick {B} if: {condition 1}, {condition 2}.
Pick {C} if: {condition 1}, {condition 2}.
```

This block is highly Featured-Snippet-friendly. If the SERP shows a Featured Snippet for the target keyword, this H2 is your best capture vehicle (besides the dedicated Featured Snippet block).

## Schema requirements

Required:
- `Organization`
- `BreadcrumbList`
- `Article`
- `FAQPage`
- `HowTo` (for the "Quick Start" decision steps block)

Strongly recommended:
- `SoftwareApplication` (one per product compared)

## FAQ slot composition for comparison pages

Hit at least 4 of these slots:
1. **PAA verbatim** (from SERP research) — usually `Is {Product A} better than {Product B}?` or similar
2. **Reverse / honest** — `Is {our product} really bad at X?` (acknowledge the criticism, then nuance)
3. **Combination** — `Can I use {A} and {B} together?`
4. **Adjacent competitor** — `What about {smaller competitor not in main comparison}?`
5. **ROI** — `Can a small team justify {our product} cost?`
6. **Proof** — `Do you have side-by-side examples with real data?`

## Featured Snippet target

For comparison pages, the Featured Snippet question is almost always:

`Which is the best {category} for {use case}?`

Build the block to answer in 40-60 words, leading with the conclusion:

```
For {specific use case}, {our product} leads with {specific differentiator + number}. {Competitor A} fits {their best-fit segment}, and {Competitor B} suits {their best-fit segment}. The right choice depends on {1-2 decision dimensions}.
```

## Common failure modes (watch for)

- Writing as if your product wins on every dimension → reader stops trusting the page
- Vague "depends on your needs" closers → defeats the purpose of a comparison
- Comparing on dimensions that don't matter to the buyer (e.g., feature counts when buyers care about accuracy)
- No quantitative data → page reads like a brochure
- Skipping TCO → buyers will mentally discount the rest
